
# Streaming Application to read from Kafka
# This should be the driver file for your project

# Importing all the required function
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *
from datetime import datetime
import uuid

# Creating Spark Session 
spark = SparkSession  \
        .builder  \
        .appName("CapStone_Project")  \
        .master("local")   \
        .getOrCreate()
spark.sparkContext.setLogLevel('ERROR')
sc = spark.sparkContext

# Adding the required python files
sc.addPyFile('db/dao.py')
sc.addPyFile('db/geo_map.py')
sc.addFile('rules/rules.py')

# Importing all the required files
import dao
import geo_map
from rules import rules_check

# Reading from Kafka stream
lines = spark  \
        .readStream  \
        .format("kafka")  \
        .option("kafka.bootstrap.servers","18.211.252.152:9092")  \
        .option("subscribe","transactions-topic-verified")  \
        .option("failOnDataLoss","false").option("startingOffsets","earliest")  \
        .load()

# Defining Schema
JSON_Schema =  StructType([
                StructField("card_id", StringType()),
                StructField("member_id", StringType()),
                StructField("amount", IntegerType()),
                StructField("pos_id", StringType()),
                StructField("postcode", StringType()),
                StructField("transaction_dt", StringType())
            ])

# Parsing the data
df=lines.select(from_json(col("value").cast("string"), JSON_Schema).alias("data")).select("data.*")

# Adding Time stamp column
df = df.withColumn('transaction_dt_ts',unix_timestamp(df.transaction_dt, 'dd-MM-YYYY HH:mm:ss').cast(TimestampType()))

#Added to ignore blank batches
df = df.na.drop(subset=["card_id"]) 

# Function for Credit Score
def get_score(a):
    hdao = dao.HBaseDao.get_instance()
    data_fetch = hdao.get_data(key=a, table='lookup_data_hbase')
    return float(data_fetch[b'lookup_card_family:score'])

# Function for Postal Code
def get_postcode(a):
    hdao = dao.HBaseDao.get_instance()
    data_fetch = hdao.get_data(key=a, table='lookup_data_hbase')
    return int(data_fetch[b'lookup_card_family:postcode'])

# Function for UCL
def get_ucl(a):
    hdao = dao.HBaseDao.get_instance()
    data_fetch = hdao.get_data(key=a, table='lookup_data_hbase')
    return float(data_fetch[b'lookup_card_family:ucl'])

# Function for Transaction Date
def get_last_Trans_date(a):
    hdao = dao.HBaseDao.get_instance()
    data_fetch = hdao.get_data(key=a, table='lookup_data_hbase')
    return data_fetch[b'lookup_card_family:transaction_dt'].decode()

# Defining UDF for Credit Score
score_udf = udf(get_score,StringType())

# Adding Score Column
df = df.withColumn("score",score_udf(df.card_id))

# Defining UDF for Postal Code
postcode_udf = udf(get_postcode,StringType())

# Adding Postal Code Column
df = df.withColumn("last_postcode", postcode_udf(df.card_id))

# Defining UDF for UCL
ucl_udf = udf(get_ucl,StringType())

# Adding UCL Column
df = df.withColumn("UCL", ucl_udf(df.card_id))

# Defining UDF for Transaction Date
Last_trans_date_udf = udf(get_last_Trans_date,StringType())

# Adding Transaction Date Column
df = df.withColumn("last_transaction_dt",Last_trans_date_udf(df.card_id))

# Function for Calculating distance
def dist_calc(last_postcode,postcode):
    gmap = geo_map.GEO_Map.get_instance()
    last_lat = gmap.get_lat(last_postcode)
    last_long = gmap.get_long(last_postcode)
    lat = gmap.get_lat(postcode)
    long = gmap.get_long(postcode)
    d = gmap.distance(last_lat.values[0],last_long.values[0],lat.values[0],long.values[0])
    return d

# Defining UDF for Distance
distance_udf = udf(dist_calc,DoubleType())

# Adding Distance Column
df = df.withColumn("distance",distance_udf(df.last_postcode,df.postcode))


# Function to Calculate Time
def time_calc(last_date,curr_date):
    d = curr_date - datetime.strptime(last_date, '%Y-%m-%d %H:%M:%S')
    return d.total_seconds()

# Defining UDF for Calculating Time
time_udf = udf(time_calc,DoubleType())

# Adding Time diff column
df = df.withColumn('time_diff',time_udf(df.last_transaction_dt,df.transaction_dt_ts))

def convert_to_byte(val):
    return bytes(str(val), encoding='utf8')

# Function to define the Status of the Transaction
def status_def(card_id,member_id,amount,pos_id,postcode,transaction_dt,transaction_dt_ts,last_transaction_dt,score,distance,time_diff, ucl):
    hdao = dao.HBaseDao.get_instance()
    geo = geo_map.GEO_Map.get_instance()
    look_up = hdao.get_data(key=card_id, table='lookup_data_hbase')
    status = 'FRAUD'
    if rules_check(ucl,score,distance,time_diff,amount):
        status = 'GENUINE'
        update_row = {}
        update_row['lookup_card_family:postcode'] = str(postcode)
        update_row['lookup_card_family:transaction_dt'] = str(transaction_dt_ts)
        hdao.write_data(card_id, update_row,'lookup_data_hbase')
    row = {
        'transactions:card_id': convert_to_byte(card_id),
        'transactions:member_id': convert_to_byte(member_id),
        'transactions:amount': convert_to_byte(amount),
        'transactions:postcode': convert_to_byte(postcode),
        'transactions:pos_id': convert_to_byte(pos_id),
        'transactions:transaction_dt': convert_to_byte(transaction_dt),
        'transactions:status': convert_to_byte(status)
    }
    trans_id = uuid.uuid4()
    # key = '{0}.{1}.{2}.{3}'.format(card_id,member_id,str(transaction_dt),str(datetime.now())).replace(" ","").replace(":", "")
    hdao.write_data(convert_to_byte(trans_id),row,'transaction_hbase')
    return status

# Defining UDF for Status
status_udf = udf(status_def,StringType())

# Adding Status Column
df = df.withColumn('status',status_udf(df.card_id,df.member_id,df.amount,df.pos_id,
                                                     df.postcode,df.transaction_dt,df.transaction_dt_ts,
                                                     df.last_transaction_dt,df.score,df.distance,df.time_diff, df.UCL))

# Displaying only required columns
df = df.select("card_id","member_id","amount","pos_id","postcode","transaction_dt_ts","status")

# Printing Output on Console
query = df \
        .writeStream  \
        .outputMode("append")  \
        .format("console")  \
        .option("truncate", "False")  \
        .start()

print("awaiting stream termination")

# Terminating the Query
query.awaitTermination()