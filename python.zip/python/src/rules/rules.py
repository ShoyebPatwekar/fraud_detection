# List all the functions to check for the rules

# Function to define rules
def rules_check(ucl,score,distance,time_diff,amount):
    if float(amount) < float(ucl):
        if float(time_diff) < (float(distance)*4):
            if float(score) > 200:
                return True
    return False